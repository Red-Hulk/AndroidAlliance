const express = require('express')

const logger = require('./src/config/config').logger

const trainingRoute = require('./src/route/training.route')
const scheduleRoute = require('./src/route/schedule.route')
const authenticationRoute = require('./src/route/authentication.route')
const adminRoute = require('./src/route/admin.route')

const app = express()

/* Use the port stored in the environment variables or port 3000 when no port is set in the environment variables */
const port = process.env.PORT || 3000

app.use(express.json())

/* Generic handling */
app.all('*', (req, res, next) => {
    logger.info('Called generic handling')
    const { method, url } = req
    logger.info(`${method} ${url}`)
    next()
})

/* Initialize API endpoints */
app.use('/api1/training', trainingRoute)
app.use('/api1/schedule', scheduleRoute)
app.use('/api1/auth', authenticationRoute)
app.use('/api1/admin', adminRoute)

//Handle non existing endpoints
app.all('*', (req, res, next) => {
    const { method, url } = req
    const errorMessage = `${method} ${url} does not exist.`
    logger.warn(errorMessage)
    const errorObject = {
        message: errorMessage,
        code: 404,
        date: new Date()
    }
    next(errorObject)
})

/* Error handler */
app.use((error, req, res, next) => {
    logger.error('Error handler: ', error.message.toString())
    res.status(error.code).json(error)
})

app.listen(port, () => logger.info(`Example app listening on port ${port}`))

module.exports = app
