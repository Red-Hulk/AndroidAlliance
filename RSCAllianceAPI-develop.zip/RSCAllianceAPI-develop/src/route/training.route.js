const express = require('express')
const router = express.Router()
const trainingController = require('../controller/training.controller')
const authenticationController = require('../controller/authentication.controller')

/* Training endpoints */
router.get('/', authenticationController.validateToken, trainingController.getAllTrainings)
router.get('/:trainingId', authenticationController.validateToken, trainingController.getTrainingById)
router.get('/schedule/:scheduleId', authenticationController.validateToken, trainingController.getTrainingsByScheduleId)
router.get('/search/:searchQuery', authenticationController.validateToken, trainingController.findTrainingsByName)
router.post('/', authenticationController.validateToken, authenticationController.validateAdmin, trainingController.createTraining)
router.put('/:trainingId', authenticationController.validateToken, authenticationController.validateAdmin, trainingController.updateTraining)

module.exports = router
