const express = require('express')
const router = express.Router()
const userController = require('../controller/user.controller')
const authenticationController = require('../controller/authentication.controller')

/* User endpoints. Always call validateAdmin() after validateToken() to check if the logged in user is an admin */
router.get('/user', authenticationController.validateToken, authenticationController.validateAdmin,
    userController.getAllAccounts)
router.post('/user/grant_admin_privileges/:userId', authenticationController.validateToken, authenticationController.validateAdmin,
    userController.grantAdminPrivileges)
router.post('/user/revoke_admin_privileges/:userId', authenticationController.validateToken, authenticationController.validateAdmin,
    userController.revokeAdminPrivileges)
router.post('/user/approve_user/:userId', authenticationController.validateToken, authenticationController.validateAdmin,
    userController.approveUser)
router.post('/user/revoke_user/:userId', authenticationController.validateToken, authenticationController.validateAdmin,
    userController.revokeUser)

module.exports = router