const express = require('express')
const router = express.Router()
const scheduleController = require('../controller/schedule.controller')
const authenticationController = require('../controller/authentication.controller')

/* Schedule endpoints */
router.get('/', authenticationController.validateToken, scheduleController.getScheduleOverview)
router.get('/:scheduleId', authenticationController.validateToken, scheduleController.getScheduleById)
router.get('/trainer/:trainerId', authenticationController.validateToken, scheduleController.getScheduleByTrainerId)

module.exports = router
