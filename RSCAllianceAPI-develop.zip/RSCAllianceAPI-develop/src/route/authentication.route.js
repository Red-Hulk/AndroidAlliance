const express = require('express')
const router = express.Router()

const authenticationController = require('../controller/authentication.controller')

/* Authentication endpoints */
router.post('/login', authenticationController.verifyUser)
router.post('/register', authenticationController.registerUser)

module.exports = router
