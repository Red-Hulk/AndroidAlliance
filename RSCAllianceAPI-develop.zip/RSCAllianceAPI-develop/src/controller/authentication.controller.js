const logger = require('../config/config').logger
const privateKey = require('../config/config').privateKey
const userDao = require('../dao/user.dao')
const validator = require('./validator')

const assert = require('assert')
const jwt = require('jsonwebtoken')
const bcrypt = require('bcrypt')

/**
 * Functions containing logic for authentication
 * @author Sam Fober
 */
module.exports = {
    validateToken: (req, res, next) => {
        logger.info('validateToken called')

        /* Get authorization header from the request */
        let authorizationHeader = req.headers.authorization

        logger.info(`Authorization header: ${authorizationHeader}`)

        /* Check if the authorization header exists */
        if (!authorizationHeader) {
            const errorObject = {
                message: 'Authorization header is missing.',
                code: 401
            }
            return next(errorObject)
        }

        /* If the authorization header begins with 'Bearer ', remove it. */
        if (authorizationHeader.startsWith('Bearer ')) {
            authorizationHeader = authorizationHeader.slice(7, authorizationHeader.length)
        }

        /* Verify the token in the authorization header */
        jwt.verify(authorizationHeader, privateKey, (error, payload) => {
            if (error) {
                const errorObject = {
                    message: 'Token is invalid',
                    code: 401
                }
                next(errorObject)
            }

            /* Check if the token has a user ID in the payload. */
            if (payload.data && payload.data.userId) {
                logger.debug('Token is valid!', payload)
                req.userId = payload.data.userId
                next()
            } else {
                const errorObject = {
                    message: 'User is missing',
                    code: 401
                }
                next(errorObject)
            }
        })
    },

    validateAdmin: (req, res, next) => {
        const userId = req.userId
        logger.trace(userId)
        userDao.getUserById(userId, (error, result) => {
            if (error) {
                logger.error(error)
                const errorObject = {
                    message: `An internal server error occurred: ${error}`,
                    code: 500
                }
                next(errorObject)
            } else if (result) {
                const user = result[0]
                logger.trace(user)
                if (user.is_admin == 0) {
                    logger.debug('User is NOT an admin!')
                    const errorObject = {
                        message: 'You have no permission to perform this operation',
                        code: 401
                    }
                    next(errorObject)
                } else if (user.is_admin == 1) {
                    logger.debug('User IS an admin!')
                    next()
                }
            }
        })
    },

    registerUser: (req, res, next) => {
        logger.info('registerUser called')

        /* Get the user object from the request body */
        const user = req.body
        logger.trace(user)

        /* Check if the input is valid */
        validator.validateUser(user, (error, isValidated) => {
            if (error) {
                const errorObject = {
                    message: error.toString(),
                    code: 400
                }
                return next(errorObject)
            } else if (isValidated) {
                logger.info('User is validated. Hashing password...')

                /* Generate the salt for the hash */
                bcrypt.genSalt(10, (error, salt) => {
                    if (error) {
                        const errorObject = {
                            message: 'Failed to generate salt.',
                            code: 500
                        }
                        next(errorObject)
                    } else if (salt) {
                        /* Hash password with the salt */
                        bcrypt.hash(user.password, salt, (error, hash) => {
                            if (error) {
                                const errorObject = {
                                    message: 'Failed to hash the password.',
                                    code: 500
                                }
                                next(errorObject)
                            } else if (hash) {
                                /* Set the password in the user object to the hashed version and store the user in the database */
                                user.password = hash
                                logger.info('Password hashed successfully! Adding user to database...')
                                userDao.insertUser(user, (error, result) => {
                                    if (error) {
                                        const errorObject = {
                                            message: 'An error occurred in the database',
                                            code: 500
                                        }
                                        next(errorObject)
                                    } else if (result) {
                                        logger.info('User registered!')
                                        res.status(200).json({ user: result })
                                    }
                                })
                            }
                        })
                    }
                })
            }
        })
    },

    verifyUser: (req, res, next) => {
        logger.info('validateUser called.')

        /* Get the user object from the request body */
        const user = req.body
        logger.trace(user)

        try {
            /* Check if input is valid */
            assert.strictEqual(typeof user.email, 'string', 'Email address is missing.')
            assert.strictEqual(typeof user.password, 'string', 'Password is missing.')

            /* Get the user ID and password from the database that match with the email address */
            userDao.getUserByEmail(user.email, (error, result) => {
                if (error) {
                    const errorObject = {
                        message: `Er is een interne serverfout opgetreden: ${error}`,
                        code: 500
                    }
                    next(errorObject)
                } else if (result) {
                    let userResult = result[0]
                    let password = user.password
                    /* Check if the result array is bigger than 0. It it's 0, the user doesn't exist.*/
                    if (result.length > 0) {
                        /* Check if the passwords match */
                        bcrypt.compare(password, userResult.password, (error, valid) => {
                            if (error) {
                                logger.error(error)
                                const errorObject = {
                                    message: 'Something went wrong while checking the password.',
                                    code: 500
                                }
                                next(errorObject)
                            } else if (valid) {
                                logger.info('Passwords match!')

                                if (userResult.is_approved == 0) {
                                    logger.info('Account not approved!')
                                    const errorObject = {
                                        message:
                                            'Dit account is nog niet goedgekeurd. Wacht alstublieft tot het account goedgekeurd is of neem contact op met uw beheerder.',
                                        code: 401
                                    }
                                    next(errorObject)
                                } else {
                                    logger.info('Account approved!')
                                    /* User is approved. Put the user ID in the payload for the token. */
                                    const payload = {
                                        userId: userResult.user_id
                                    }

                                    /* Sign the token */
                                    jwt.sign({ data: payload }, privateKey, { expiresIn: 60 * 60 * 24 }, (error, token) => {
                                        if (error) {
                                            logger.error(error)
                                            const errorObject = {
                                                message: 'Something went wrong wile generating the token.',
                                                code: 500
                                            }
                                            next(errorObject)
                                        } else if (token) {
                                            res.status(200).json({
                                                session: {
                                                    user: {
                                                        first_name: userResult.first_name,
                                                        last_name: userResult.last_name,
                                                        is_admin: userResult.is_admin
                                                    },
                                                    token: token
                                                }
                                            })
                                        }
                                    })
                                }
                            } else if (!valid) {
                                const errorObject = {
                                    message: 'Het emailadres en/of wachtwoord zijn niet juist.',
                                    code: 401
                                }
                                next(errorObject)
                            }
                        })
                    } else {
                        const errorObject = {
                            message: 'Het emailadres en/of wachtwoord zijn niet juist.',
                            code: 401
                        }
                        next(errorObject)
                    }
                }
            })
        } catch (exception) {
            const errorObject = {
                message: exception.toString(),
                code: 500
            }
            return next(errorObject)
        }
    }
}
