const logger = require('../config/config').logger
const trainingDao = require('../dao/training.dao')

/**
 * Functions containing logic for training items
 * @author Sam Fober
 */
module.exports = {
    createTraining: (req, res, next) => {
        logger.info('createTraining called')
        const training = req.body
        logger.trace(training)

        trainingDao.insertTraining(training, (error, results) => {
            if (error) {
                const errorObject = {
                    message: `An internal server error occurred: ${error}`,
                    code: 500
                }
                next(errorObject)
            } else if (results) {
                res.status(200).json({})
            }
        })
    },

    updateTraining: (req, res, next) => {
        logger.info('updateTraining called')
        const training = req.body
        logger.trace(training)

        const trainingId = req.params.trainingId

        trainingDao.getTrainingById(trainingId, (error, result) => {
            if (error) {
                const errorObject = {
                    message: `Er is een interne serverfout opgetreden: ${error}`,
                    code: 500
                }
                next(errorObject)
            } else if (result) {
                /* Check if the size of the results array is 0. If it's 0, the training doesn't exist. */
                if (result.length == 0) {
                    const errorObject = {
                        message: 'Geen training gevonden met het gegeven training ID.',
                        code: 404
                    }
                    next(errorObject)
                } else {
                    trainingDao.updateTraining(training, (error, results) => {
                        if (error) {
                            const errorObject = {
                                message: `An internal server error occurred: ${error}`,
                                code: 500
                            }
                            next(errorObject)
                        } else if (results) {
                            res.status(200).json({})
                        }
                    })
                }
            }
        })
    },

    getAllTrainings: (req, res, next) => {
        logger.info('getAllTrainings called in training controller')
        trainingDao.getAllTrainings((error, result) => {
            if (error) {
                const errorObject = {
                    message: `An internal server error occurred: ${error}`,
                    code: 500
                }
                next(errorObject)
            } else if (result) {
                const trainings = result
                res.status(200).json({ trainings })
            }
        })
    },

    getTrainingById: (req, res, next) => {
        logger.info('getTrainingById called in training controller')
        const id = req.params.trainingId

        /* Get the training from the database */
        trainingDao.getTrainingById(id, (error, result) => {
            if (error) {
                const errorObject = {
                    message: `Er is een iterne serverfout opgetreden: ${error}`,
                    code: 500
                }
                next(errorObject)
            } else if (result) {
                /* Check if the size of the results array is 0. If it's 0, the training doesn't exist. */
                if (result.length == 0) {
                    const errorObject = {
                        message: 'Geen training gevonden met het gegeven training ID.',
                        code: 404
                    }
                    next(errorObject)
                } else {
                    const trainings = result
                    res.status(200).json({ trainings })
                }
            }
        })
    },

    getTrainingsByScheduleId: (req, res, next) => {
        logger.info('getTrainingsByScheduleId called.')
        const scheduleId = req.params.scheduleId
        logger.info(`Looking up trainings with the following schedule ID: ${scheduleId}`)
        trainingDao.getTrainingsByScheduleId(scheduleId, (error, result) => {
            if (error) {
                const errorObject = {
                    message: `An internal server error occurred: ${error}`,
                    code: 500
                }
                next(errorObject)
            } else if (result) {
                /* Check if the size of the results array is 0. If it's 0, the trainings don't exist. */
                if (result.length == 0) {
                    const errorObject = {
                        message: 'Geen trainingen gevonden met het gegeven rooster ID.',
                        code: 404
                    }
                    next(errorObject)
                } else {
                    const trainings = result
                    res.status(200).json({ trainings })
                }
            }
        })
    },

    findTrainingsByName: (req, res, next) => {
        logger.info('findTrainingsByName called.')
        const searchQuery = req.params.searchQuery
        logger.info(`Looking up trainings with the following search query: ${searchQuery}`)
        trainingDao.getTrainingsByName(searchQuery, (error, result) => {
            if (error) {
                const errorObject = {
                    message: `An internal server error occurred: ${error}`,
                    code: 500
                }
                next(errorObject)
            } else if (result) {
                if (result.length == 0) {
                    const errorObject = {
                        message: 'Geen trainingen gevonden met de gegeven zoekopdracht',
                        code: 404
                    }
                    next(errorObject)
                } else {
                    const trainings = result
                    res.status(200).json({ trainings })
                }
            }
        })
    }
}
