const logger = require('../config/config').logger
const userDao = require('../dao/user.dao')

/**
 * Functions containing logic for user items
 * @author Sam Fober
 */
module.exports = {
    /**
     * Gets all the accounts from the database
     * @param req
     * @param res
     * @param next
     */
    getAllAccounts: (req, res, next) => {
        logger.info('getAllAccounts called')
        userDao.getAllUsers((error, result) => {
            if (error) {
                const errorObject = {
                    message: `Er is een interne serverfout opgetreden: ${error}`,
                    code: 500
                }
                next(errorObject)
            } else if (result) {
                const users = result
                res.status(200).json({ users })
            }
        })
    },

    grantAdminPrivileges: (req, res, next) => {
        logger.info('grantAdminPrivileges called')
        const userId = req.params.userId
        logger.trace(userId)
        userDao.getUserById(userId, (error, results) => {
            if (error) {
                const errorObject = {
                    message: `Er is een interne serverfout opgetreden: ${error}`,
                    code: 500
                }
                next(errorObject)
            } else if (results) {
                if (results.length == 0) {
                    const errorObject = {
                        message: 'Geen account gevonden met het gegeven ID.',
                        code: 404
                    }
                    next(errorObject)
                } else {
                    const user = results[0]
                    user.is_admin = 1
                    userDao.updateUser(user, (error, results) => {
                        if (error) {
                            const errorObject = {
                                message: `Er is een interne serverfout opgetreden: ${error}`,
                                code: 500
                            }
                            next(errorObject)
                        } else if (results) {
                            logger.trace(results)
                            res.status(200).json({ results })
                        }
                    })
                }
            }
        })
    },

    approveUser: (req, res, next) => {
        logger.info('approveUser called')
        const userId = req.params.userId
        logger.trace(userId)
        userDao.getUserById(userId, (error, results) => {
            if (error) {
                const errorObject = {
                    message: `Er is een interne serverfout opgetreden: ${error}`,
                    code: 500
                }
                next(errorObject)
            } else if (results) {
                if (results.length == 0) {
                    const errorObject = {
                        message: 'Geen account gevonden met het gegeven ID.',
                        code: 404
                    }
                    next(errorObject)
                } else {
                    const user = results[0]
                    user.is_approved = 1
                    userDao.updateUser(user, (error, results) => {
                        if (error) {
                            const errorObject = {
                                message: `Er is een interne serverfout opgetreden: ${error}`,
                                code: 500
                            }
                            next(errorObject)
                        } else if (results) {
                            logger.trace(results)
                            res.status(200).json({ results })
                        }
                    })
                }
            }
        })
    },

    revokeUser: (req, res, next) => {
        logger.info('revokeUser called.')
        const userId = req.params.userId
        logger.trace(userId)
        userDao.getUserById(userId, (error, results) => {
            if (error) {
                const errorObject = {
                    message: `Er is een interne serverfout opgetreden: ${error}`,
                    code: 500
                }
                next(errorObject)
            } else if (results) {
                if (results.length == 0) {
                    const errorObject = {
                        message: 'Geen account gevonden met het gegeven ID.',
                        code: 404
                    }
                    next(errorObject)
                } else {
                    const user = results[0]
                    user.is_approved = 0
                    userDao.updateUser(user, (error, results) => {
                        if (error) {
                            const errorObject = {
                                message: `Er is een interne serverfout opgetreden: ${error}`,
                                code: 500
                            }
                            next(errorObject)
                        } else if (results) {
                            logger.trace(results)
                            res.status(200).json({ results })
                        }
                    })
                }
            }
        })
    },

    revokeAdminPrivileges: (req, res, next) => {
        logger.info('grantAdminPrivileges called')
        const userId = req.params.userId
        logger.trace(userId)
        userDao.getUserById(userId, (error, results) => {
            if (error) {
                const errorObject = {
                    message: `Er is een interne serverfout opgetreden: ${error}`,
                    code: 500
                }
                next(errorObject)
            } else if (results) {
                if (results.length == 0) {
                    const errorObject = {
                        message: 'Geen account gevonden met het gegeven ID.',
                        code: 404
                    }
                    next(errorObject)
                } else {
                    const user = results[0]
                    user.is_admin = 0
                    userDao.updateUser(user, (error, results) => {
                        if (error) {
                            const errorObject = {
                                message: `Er is een interne serverfout opgetreden: ${error}`,
                                code: 500
                            }
                            next(errorObject)
                        } else if (results) {
                            logger.trace(results)
                            res.status(200).json({ results })
                        }
                    })
                }
            }
        })
    }
}