const assert = require('assert')
const logger = require('../config/config').logger
const validators = require('../config/config').validators

/**
 * Functions to validate input
 * @author Sam Fober
 */
module.exports = {
    validateUser: (user, callback) => {
        logger.info('validateUser called.')
        try {
            assert.strictEqual(typeof user.first_name, 'string', 'Voornaam ontbreekt')
            assert.strictEqual(typeof user.last_name, 'string', 'Achternaam ontbreekt')
            assert.strictEqual(typeof user.email, 'string', 'Emailadres ontbreekt')
            assert.strictEqual(typeof user.password, 'string', 'Wachtwoord ontbreekt')

            user.email.match(validators.emailValidator, 'Emailadres is niet geldig.')
            callback(null, true)
        } catch (exception) {
            callback(exception, null)
        }
    }
}
