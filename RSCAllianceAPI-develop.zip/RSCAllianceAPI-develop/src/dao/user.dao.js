const pool = require('../config/config').pool
const logger = require('../config/config').logger

/**
 * Functions to perform database operations for user items.
 * @author Sam Fober
 */
module.exports = {
    getUserByEmail: (emailAddress, callback) => {
        logger.info('getUserIdAndPasswordByEmail called.')
        pool.query('SELECT * FROM user WHERE email = ?', [emailAddress], (error, results, fields) => {
            if (error) {
                logger.error(error)
                callback(error, null)
            } else if (results) {
                logger.info('Results found: ', results)
                callback(null, results)
            }
        })
    },

    /**
     * Gets a user from the database matching a given user ID
     * @param userId The user ID to look up in the database
     * @param callback error | results
     */
    getUserById: (userId, callback) => {
        logger.info('getUserById called')
        pool.query('SELECT * FROM user WHERE user_id = ?', [userId], ((error, results, fields) => {
            if (error) {
                logger.error(error)
                callback(error, null)
            } else if (results) {
                logger.trace(results)
                callback(null, results)
            }
        }))
    },

    /**
     * Gets all the users from the database
     * @param callback error | results
     */
    getAllUsers: (callback) => {
        logger.info('getAllUsersCalled')
        pool.query('SELECT * FROM user', [], ((error, results, fields) => {
            if (error) {
                logger.error(error)
                callback(error, null)
            } else if (results) {
                logger.trace(results)
                callback(null, results)
            }
        }))
    },

    /**
     * Inserts a user in the database
     * @param user The user to add
     * @param callback error | results
     */
    insertUser: (user, callback) => {
        logger.info('insertUser called.')
        pool.query(
            'INSERT INTO user (email, password, first_name, last_name, is_approved, is_admin) VALUES (? ,?, ?, ?, ?, ?)',
            [user.email, user.password, user.first_name, user.last_name, user.is_approved, user.is_admin],
            (error, results, fields) => {
                if (error) {
                    logger.error(error)
                    callback(error, null)
                } else if (results) {
                    callback(null, results)
                }
            }
        )
    },

    updateUser: (user, callback) => {
        logger.info('updateUser called.')
        logger.trace(user)
        pool.query(`UPDATE user SET email = ?, password = ?, first_name = ?, last_name = ?, is_approved = ?, 
                        is_admin = ? WHERE user_id = ?`,
            [user.email, user.password, user.first_name, user.last_name, user.is_approved, user.is_admin, user.user_id],
            ((error, results, fields) => {
                    if (error) {
                        logger.error
                        callback(error, null)
                    } else if (results) {
                        callback(null, results)
                    }
                }
            )
        )
    }
}
