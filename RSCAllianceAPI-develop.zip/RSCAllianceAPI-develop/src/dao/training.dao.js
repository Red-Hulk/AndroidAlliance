const pool = require('../config/config').pool
const logger = require('../config/config').logger

/**
 * Functions to perform database operations for training items
 * @author Sam Fober
 */
module.exports = {
    getAllTrainings: callback => {
        pool.query('SELECT * FROM training', (error, results, fields) => {
            if (error) {
                logger.error(error)
                callback(error, null)
            } else if (results) {
                logger.info('Results found: ', results)
                callback(null, results)
            }
        })
    },

    getTrainingById: (id, callback) => {
        pool.query('SELECT * FROM training WHERE id = ?', [id], (error, results, fields) => {
            if (error) {
                logger.error(error)
                callback(error, null)
            } else if (results) {
                logger.info('Results found: ', results)
                callback(null, results)
            }
        })
    },

    getTrainingsByScheduleId: (id, callback) => {
        pool.query('SELECT * FROM view_scheduled_trainings WHERE schedule_id = ?', [id], (error, results, fields) => {
            if (error) {
                logger.error(error)
                callback(error, null)
            } else if (results) {
                logger.info('Results found: ', results)
                callback(null, results)
            }
        })
    },

    getTrainingsByName: (name, callback) => {
        pool.query('SELECT * FROM training WHERE name LIKE ?', ['%' + name + '%'], (error, results, fields) => {
            if (error) {
                logger.error(error)
                callback(error, null)
            } else if (results) {
                logger.info('Results found: ', results)
                callback(null, results)
            }
        })
    },

    insertTraining: (training, callback) => {
        pool.query(`INSERT INTO training (
                        name, age_category, required_material, goal, warming_up_phase, training_phase, orientation_phase, application_phase, 
                        p_learning_phase, completion_phase, team_form, competition_form, legend_url) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [training.name, training.age_category, training.required_material,
            training.goal, training.warming_up_phase, training.training_phase, training.orientation_phase, training.application_phase,
            training.p_learning_phase, training.completion_phase, training.team_form, training.competition_form, training.legend_url], (error, results, fields) => {
            if (error) {
                logger.error(error)
                callback(error, null)
            } else if (results) {
                logger.info('Training added!')
                callback(null, results)
            }
        })
    },

    updateTraining: (training, callback) => {
        pool.query(`UPDATE training SET name = ?, age_category = ?, required_material = ?, goal = ?, warming_up_phase = ?, training_phase = ?, orientation_phase = ?, application_phase = ?, 
                        p_learning_phase = ?, completion_phase = ?, team_form = ?, competition_form = ?, legend_url = ? WHERE id = ?`, [training.name, training.age_category, training.required_material,
            training.goal, training.warming_up_phase, training.training_phase, training.orientation_phase, training.application_phase,
            training.p_learning_phase, training.completion_phase, training.team_form, training.competition_form, training.legend_url, training.id], (error, results, fields) => {
            if (error) {
                logger.error(error)
                callback(error, null)
            } else if (results) {
                logger.info('Training updated!')
                callback(null, results)
            }
        })
    }
}
