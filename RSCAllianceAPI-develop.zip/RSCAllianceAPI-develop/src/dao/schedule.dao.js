const pool = require('../config/config').pool
const logger = require('../config/config').logger

/**
 * Functions to perform database operation for schedule items
 * @author Sam Fober
 */
module.exports = {
    getScheduleOverview: callback => {
        pool.query('SELECT * FROM schedule', (error, results, fields) => {
            if (error) {
                logger.error(error)
                callback(error, null)
            } else if (results) {
                logger.info('Results found: ', results)
                callback(null, results)
            }
        })
    },

    getScheduleById: (id, callback) => {
        pool.query('SELECT * FROM schedule WHERE id = ?', [id], (error, results, fields) => {
            if (error) {
                logger.error(error)
                callback(error, null)
            } else if (results) {
                logger.info('Results found: ', results)
                callback(null, results)
            }
        })
    },

    getScheduleByTrainerId: (id, callback) => {
        pool.query('SELECT * FROM schedule WHERE trainer_id = ?', [id], (error, results, fields) => {
            if (error) {
                logger.error(error)
                callback(error, null)
            } else if (results) {
                logger.info('Results found: ', results)
                callback(null, results)
            }
        })
    }
}
